import React, { useReducer, useContext } from "react";

// Images import


const cartItems = [
  {
    id: "product-1",
    url: "https://5.imimg.com/data5/QX/OQ/MY-35834836/acrylic-name-plate-500x500.jpg",
    productName: "Acrylic Light",
    price: "300",
    quantity: 10,
    totalAmount: "3000",
  },
  {
    id: "product-6",
    url: "https://static.connect2india.com/c2icd/product_resources/images/steel-name-board.jpg",
    productName: "Stainless Steel",
    price: "300",
    quantity: 3,
    totalAmount: "900",
  },
];
// Cart context
const CartContext = React.createContext({
  cartItems: [],
  cartDispatchFn: () => {},
});

// Cart Reducer fn
const cartReducer = (prevState, action) => {
  let updatedArray;
  if (action.type === "GET_CART_ITEMS") {
    updatedArray = [...action.value];
    return updatedArray;
  } else if (action.type === "ADD_TO_CART") {
    action.value.totalAmount = (
      action.value.quantity * action.value.price
    ).toFixed(2);
    updatedArray = [action.value, ...prevState];
    return updatedArray;
  } else if (action.type === "SAVE_EDITED_PRODUCT") {
    const exsistedItem = prevState.find((item) => {
      return action.value.id === item.id;
    });
    const index = prevState.indexOf(exsistedItem);
    action.value.totalAmount = (
      action.value.quantity * action.value.price
    ).toFixed(2);
    const cloneProduct = { ...action.value };
    updatedArray = [...prevState];
    updatedArray[index] = cloneProduct;
    return updatedArray;
  } else if (action.type === "REMOVE_FROM_CART") {
    updatedArray = [
      ...prevState.filter((item) => {
        return item.id !== action.value;
      }),
    ];
    return updatedArray;
  }
  return prevState;
};

// Cart Context Provider
 export const CartContextProvider = (props) => {
  const [cartState, cartDispatchFn] = useReducer(cartReducer, cartItems);

  return (
    <CartContext.Provider
      value={{
        cartItems: cartState,
        cartDispatchFn: cartDispatchFn,
      }}
    >
      {props.children}
    </CartContext.Provider>
  );
};

export const useCartCxt = () => {
  return useContext(CartContext);
};

export default CartContext;